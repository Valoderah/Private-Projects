'''
  * Class: 44-141 Computer Programming I
  * Author: Oderah Valentine Osakwe
  * Description: (Give a brief description for the exercise or project)
  * Due: 10/03/2016
  * I pledge that I have completed the programming assignment independently.
  * I have not copied the code from a student or any source.
  * I have not given my code to any other student and will not share this code with anyone under any circumstances.
'''
#Main Program
#Use the print statements to display three messages
print("Programming is fun")
print("Welcome to Computer Programming")
print("Python is a programming language")



import turtle

#Construct Snowman
turtle.speed(0)
x = -250
k = 0

# Use the while ;loop to construct the two snowmen
# by assigning turtle the variable x on the x axis (where to start)
while(k<2):

# Use goto, penup, pendown, left, right to move turtle
    turtle.penup()

#Set width of the turtle
    turtle.width(width=5)
#starting point
    turtle.goto(x,-250)
    turtle.pendown()
    turtle.circle(85)
    turtle.penup()
    turtle.goto(x,-75)
    turtle.pendown()
    turtle.circle(60)
    turtle.penup()
    turtle.goto(x,45)
    turtle.pendown()
    turtle.circle(40)
    k += 1
# Set the x axis to go to 500
    x += 500


turtle.penup()

#creating block

#use variable x and y to assign turtle where to go
k = 240
x = -120
y = -120
turtle.color("cyan") #assign color
while(k>=80):
    turtle.goto(x,y)
    turtle.pendown()
    turtle.begin_fill()

    if (k == 160):  #Second block
        turtle.color("orchid")

    if (k == 80):    #Third block
        turtle.color("ghostwhite")

#I use j as the variable to draw the block
    j = 0
    while (j<4):
        turtle.forward(k)
        turtle.left(90)
        j +=1
    turtle.end_fill()

#use -80 t0 decrease the box after each iteration
    k -= 80
    x += 40
    y += 40

#make Snow flake
d = 0
while (d<8):
    turtle.penup()
    turtle.color("black")
    turtle.goto(0,0)
    turtle.pendown()
    turtle.forward(50)
    turtle.left(45)
    d += 1

#write statement
turtle.penup()
turtle.goto(-110,150)
turtle.pendown()
turtle.hideturtle()
turtle.write("Sall's Snow Cones", font = ("Harrington", 20,"bold") )

turtle.done()
