'''
  * Class: 44-141 Computer Programming I
  * Author:(ODERAH VALENTINE OSAKWE)
  * Description: (PROJECT FOR PYTHON TICKETING SERVICE)
  * Due: (09/14/2016)
  * I pledge that I have completed the programming assignment independently.
  * I have not copied the code from a student or any source.
  * I have not given my code to any other student and will not share this code with anyone under any circumstances.
'''
#List prices for various tickets and assign variables
ADULT_TICKETS = 7.25
CHILD_TICKETS = 3.75
SENIOR_TICKETS = 4.50
FEES = 0.074
print("--------------------------------------------")
print("||        Python Ticketing Services       ||")
print("--------------------------------------------")
#print first heading
print()

print("***  ORDER INFORMATION  *** \n")
userName=input("Enter your name >> ")
userEmail=input("Enter your Email address >> ")
movieChoice=input("What movie will you like to see >> ")
numAdults=int(input("How many adults are in yor group? >> "))
numChildren=int(input("How many children are in your group? >> "))
numSeniors=int(input("How many seniors are in your group? >> "))
numTickets = int(numAdults + numChildren + numSeniors)
print("\n")

#print second heading
print("***  ORDER INFORMATION   *** \n")
print("Contact Name:",userName)
print("Email address:",userEmail)
print("You have ordered ", (numTickets)," for ", (movieChoice))

#Calculate Total cost of Ticket

totalCost=numAdults*ADULT_TICKETS+numChildren*CHILD_TICKETS+numSeniors*SENIOR_TICKETS
print("Your total cost of Ticket is: $",(round(totalCost + (FEES * totalCost), 2)))

print()

#print final heading
print("-------------------------------------------")
print("||              THANKS FOR USING         ||")
print("||         PYTHON TICKETING SERVICES     ||")
print("-------------------------------------------")
