'''
  * Class: 44-141 sec 03 Computer Programming I
  * Author: (Oderah Osakwe)
  * Description: (Data Mining for Amazon Stock)
  * Due: (12/5/2016)
  * I pledge that I have completed the programming assignment independently.
  * I have not copied the code from a student or any source.
  * I have not given my code to any other student and will not share this code with anyone under any circumstances.
'''
#Main Program
#Use the print statements to display three messages
print("Programming is fun")
print("Welcome to Computer Programming")
print("Python is a programming language")

#functions
def get_data_list(file_name):
    dataFile = open(file_name, "r") #Access amazon txt
    lis = []

    for i in dataFile:
        split_File=i.split(",") #split the data and convert to list
        lis.append(split_File)

    return lis

def get_monthly_averages(data_list):
    average_price=0
    storeSplit= data_list[1][0].split("-") #Split the date to keep track of the month
    Monthly = []
    oldM = storeSplit[1] #variable to keep track of month
    m=oldM[:]

    count = 0
    sum=0

    for a in data_list:
        if count!=0:
            storeSplit= a[0].split("-") #split the date and use to calculate the average
            m=storeSplit[1]
            day = storeSplit[0]
            if(m==oldM):
                zip = a[6].strip("\n")
                average_price += int(a[5])*float(zip) #calculate the average
                sum+=int(a[5])

            else: #execute and bring together in a list
                zip = a[6].strip("\n")
                myTuple = (average_price/sum,day+"-"+m)
                Monthly.append(myTuple) #append and add to list
                average_price=0
                sum=0
                average_price += int(a[5])*float(zip) #calculate the average pice
                sum+=int(a[5])
            oldM = m[:]

        count+=1 #go through the list
    return Monthly

def print_info(monthly_averages_list,filename):
    list_file = open(filename,'w')#create output file
    sort_tuple=sorted(monthly_averages_list)

    print("Amazon Stock from Jan 1, 2008 to Oct. 28, 2014")
    list_file.write("Amazon Stock from Jan 1, 2008 to Oct. 28, 2014\n")#send to output file

    print("Six worst months:")
    list_file.write("Six worst months:\n")#send to output file

    for file in range(6):#arrange the average and print the six worst month

        print(sort_tuple[file][1], "\t","{:.2f}".format(sort_tuple[file][0]))
        list_file.write(sort_tuple[file][1]+ "\t{:.2f}".format(sort_tuple[file][0])+"\n") #send to output file

    sort_tuple.reverse()#print from lowest to highest
    print()

    print("Six best months:") #Arrange the average and print the six best month
    list_file.write("Six best months:\n")

    for file in range(5,-1,-1): #print from highest to lowest
        print(sort_tuple[file][1], "\t","{:.2f}".format(sort_tuple[file][0]))
        list_file.write(sort_tuple[file][1]+ "\t{:.2f}".format(sort_tuple[file][0])+"\n")

    list_file.close()





#main Program
file = get_data_list("amazon.txt")#open file
monthlyAverage = get_monthly_averages(file)
print_info(monthlyAverage,"val")
