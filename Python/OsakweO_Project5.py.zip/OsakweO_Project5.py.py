'''
  * Class: 44-141 Computer Programming I
  * Author: Valentine Oderah Osakwe
  * Description: Write functions to determine baseball Tickets
  * Due: 11/18/2016
  * I pledge that I have completed the programming assignment independently.
  * I have not copied the code from a student or any source.
  * I have not given my code to any other student and will not share this code with anyone under any circumstances.
'''
#Main Program
#Use the print statements to display three messages
print("Programming is fun")
print("Welcome to Computer Programming")
print("Python is a programming language")

#first function to determine if user has a ticket
def ticketReader(ticketNum,fileInput):

    for name in fileInput:
        list = name.split() #return string as a split
        if (getTicketNo(list)==ticketNum):

            return list
    return "No reservation Made" # if reservations are not made it returns

#Function to get the ticket number by
def getTicketNo(ticketInfo):
    return ticketInfo[0]

#function to get first name
def getFirstName(ticketInfo):
    return ticketInfo[1]

#function to get last name
def getLastName(ticketInfo):
    return ticketInfo[2]

#function to get ticket row
def getRow(ticketInfo):
    return ticketInfo[3]

#function to get seat
def getSeat(ticketInfo):
    return ticketInfo[4]

#welcome info
def toString(ticketInfo,file):
    file.write("Welcome to Bearcats Baseball "+ getFirstName(ticketInfo)+getLastName(ticketInfo)+"\n")
    print("Welcome to Bearcats Baseball",getFirstName(ticketInfo),getLastName(ticketInfo))
    file.write("Your row is " + getRow(ticketInfo)+"\n")
    print("Your row is",getRow(ticketInfo))
    file.write("Your seat is "+getSeat(ticketInfo)+"\n")
    print("Your seat is",getSeat(ticketInfo))



#Main Program
word = 0
#create an output file to store your output
OutputFile = open("output.txt","w")
file = input("Enter your ticket number (0 to stop scanning in): ")


while file != "0" :
    #open ticket file
    myFile = open("tickets.txt", "r")

#call ticket reader function
    word = ticketReader(file,myFile)
    if word == "No reservation Made":
        print(word)
        OutputFile.write(word + "\n") #ticket info to print in ouput file

        print()
    else:
        toString(word,OutputFile) #make argument for string to write in output file
        print()
    file = input("Enter your ticket number (0 to scanning in): ")
    myFile.close()

#print have a nice day if user has not scanned any ticket
if word == 0:
    print("Have a nice day!")

#print welcome to bearcat baseball, enjoy the game if a ticket has been scanned
else:
    print("Welcome to Bearcat Baseball, enjoy the game!")

OutputFile.close()

